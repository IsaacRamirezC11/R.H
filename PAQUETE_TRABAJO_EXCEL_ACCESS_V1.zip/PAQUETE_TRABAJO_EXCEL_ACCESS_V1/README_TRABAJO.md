# Ahorro Solidario — paquete de trabajo V1

Incluye:
- Frontend Excel de trabajo.
- Borrador de estructura Access.
- Esqueleto VBA.
- Plantilla de reglas y fórmulas.
- Plan de trabajo.

No es todavía la versión de producción. La conexión Excel-Access y las consultas se implementarán después de confirmar la ruta, nombres reales y reglas del servicio.
