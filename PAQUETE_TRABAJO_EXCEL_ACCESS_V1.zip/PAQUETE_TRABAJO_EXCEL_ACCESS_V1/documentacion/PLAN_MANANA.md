# Plan de trabajo para mañana

## Objetivo
Empezar la integración Excel + Access usando la base ya normalizada.

1. Abrir Frontend_Ahorro_Solidario_V1.xlsx.
2. Confirmar los 38 encabezados contra la base real.
3. Completar reglas_sistema_V1.xlsx con las fórmulas reales.
4. Registrar catálogos/listas de captura.
5. Confirmar ruta de red y nombre exacto del .accdb.
6. Confirmar nombre de la tabla principal de Access.
7. Crear copia de prueba de Access.
8. Importar una muestra pequeña.
9. Probar búsqueda por RFC.
10. Probar histórico.
11. Probar alta.
12. Probar reportes.
13. Solo después habilitar modificaciones en producción.

## Reglas ya conocidas
- FECHA_APLICAR = FECHA_SOLICITA + 90 días (confirmar fórmula real).
- SEXO: HOMBRE/MUJER.
- %: 0/1/2 (confirmar significado).
- QNA: 1–24.
- NIVEL: 3 caracteres alfanuméricos.
- UR: 3 dígitos, conservando ceros iniciales.

## Seguridad
No subir a GitHub la base real, Q reales ni datos personales.
