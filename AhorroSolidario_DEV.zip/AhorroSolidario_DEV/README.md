# Ahorro Solidario — DEV V2

Base entregada: `AHORRO_SOLIDARIO.xlsx` — 52,391 registros, 38 campos. La columna 38 actual es `RFC_COMPLETO`.

## Ya probado aquí
- Conteo: 52,391
- RFC distintos: 47,936
- CURP distintas: 48,000
- Búsqueda del RFC de prueba: 1 registro(s).
- Histórico ordenado por Año/QNA.

## Arquitectura
Excel frontend → Access producción. SQLite es únicamente un simulador local para probar consultas en este entorno.

## Archivos
- `frontend/AhorroSolidario_FRONTEND_V2.xlsx`
- `database/01_crear_ACCESS.sql`
- `database/AhorroSolidario_TEST.sqlite`
- `vba/mod_AhorroSolidario.bas`
- `tests/test_results.json`

## Mañana
1. Abrir copia del Access.
2. Confirmar tabla/campos.
3. Importar VBA.
4. Configurar `CONFIG!C4`.
5. Probar búsqueda, histórico, alta y reportes.
6. Replicar en oficial solo después de validar.

## GitHub
No subir `AHORRO_SOLIDARIO.xlsx`, `.accdb`, `.sqlite` ni ningún archivo con datos personales.
