Attribute VB_Name = "mod_AhorroSolidario"
Option Explicit
Private Function RutaAccess() As String: RutaAccess = Trim$(CStr(ThisWorkbook.Worksheets("CONFIG").Range("C4").Value)): End Function
Private Function TablaPrincipal() As String: TablaPrincipal=Trim$(CStr(ThisWorkbook.Worksheets("CONFIG").Range("C5").Value)): If TablaPrincipal="" Then TablaPrincipal="MOVIMIENTOS"
End Function
Private Function CN() As Object: Dim c As Object: Set c=CreateObject("ADODB.Connection"): c.Open "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & RutaAccess() & ";Persist Security Info=False;": Set CN=c: End Function
Private Function Q(v As Variant) As String: If IsEmpty(v) Or Trim$(CStr(v))="" Then Q="NULL" Else Q="'" & Replace(CStr(v),"'","''") & "'" End Function
Public Sub BuscarTrabajador()
On Error GoTo E: Dim c As Object,r As Object,w As Worksheet,s As String,k As String,f As Long:Set w=Sheets("BUSQUEDA"):k=Trim$(w.Range("C4").Value):If k="" Then k=Trim$(w.Range("C5").Value):If k="" Then k=Trim$(w.Range("C6").Value):If k="" Then MsgBox "Captura RFC, CURP o NOMBRE.":Exit Sub
Set c=CN:Set r=CreateObject("ADODB.Recordset"):s="SELECT TOP 500 [RFC],[HOM],[PATERNO],[MATERNO],[NOMBRE],[CURP],[NIVEL],[UR],[QNA],[AÑO],[ALTA_BAJA],[SEXO] FROM ["&TablaPrincipal()&"] WHERE [RFC]="&Q(UCase$(w.Range("C4").Value))&" OR [CURP]="&Q(UCase$(w.Range("C5").Value))&" OR [NOMBRE] LIKE "&Q("*"&UCase$(w.Range("C6").Value)&"*")&" ORDER BY [AÑO] DESC,[QNA] DESC;":r.Open s,c,3,1:f=10:Do Until r.EOF:Dim i As Long:For i=0 To 11:w.Cells(f,2+i).Value=r.Fields(i).Value:Next i:f=f+1:r.MoveNext:Loop:MsgBox "Registros encontrados: "&(f-10)
X: On Error Resume Next:r.Close:c.Close:Exit Sub
E: MsgBox "Error: "&Err.Description,vbCritical:Resume X
End Sub
Public Sub CargarHistorico()
On Error GoTo E: Dim c As Object,r As Object,w As Worksheet,s As String,f As Long,i As Long:Set w=Sheets("HISTORICO"):If Trim$(w.Range("C4").Value)="" Then MsgBox "Captura RFC.":Exit Sub:Set c=CN:Set r=CreateObject("ADODB.Recordset"):s="SELECT [RFC],[QNA],[AÑO],[FECHA_APLICAR_AHORRO],[RESULTADO_ANALISIS],[REGIMEN_EN_SIRI_ES_EL_QUE_MAS_IMPORTANCIA_TIENE_PARA_APLICARO_AHORRO_SOLIDARIO],[ALTA_BAJA],[SEXO],[OBSERVACIONES] FROM ["&TablaPrincipal()&"] WHERE [RFC]="&Q(UCase$(w.Range("C4").Value))&" ORDER BY [AÑO] DESC,[QNA] DESC;":r.Open s,c,3,1:f=8:Do Until r.EOF:For i=0 To 8:w.Cells(f,2+i).Value=r.Fields(i).Value:Next i:f=f+1:r.MoveNext:Loop:MsgBox "Histórico: "&(f-8)&" registro(s)."
X: On Error Resume Next:r.Close:c.Close:Exit Sub
E: MsgBox "Error: "&Err.Description,vbCritical:Resume X
End Sub
